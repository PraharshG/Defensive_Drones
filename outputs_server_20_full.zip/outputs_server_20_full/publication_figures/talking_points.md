# Publication Talking Points

Dataset: `outputs_server_20_full/per_run_results.csv`.
Sample: 200 scenarios and 1800 strategy runs.

## Main Claims

- **Best overall strategy:** `earliest_deadline_collab` achieved 5.5% mission success.
- **Best attrition strategy:** `optimized_collab` achieved a mean kill ratio of 0.810.
- **Removing corridors helped optimization:** `optimized_global` improved success from 0.0% to 0.0% (+0.0 percentage points).
- **Optimized global intercepted more attackers:** mean kills rose from 583.98 to 85.58 per scenario.
- **Collaborative corridors are the middle ground:** `optimized_collab` achieved 0.5% success and 595.64 mean kills while preserving corridor-first behavior.
- **Scenario-level improvement:** `optimized_global` killed more attackers than corridor `optimized` in 0.0% of paired scenarios, tied in 0.0%, and killed fewer in 100.0%.
- **Success conversion:** `optimized_global` turned 0 scenarios from corridor-optimized failures into successes.
- **Collaboration conversion:** `optimized_collab` turned 1 corridor-optimized failures into successes and improved kill count in 93.5% of paired scenarios.
- **Deadline-first policies are not enough:** earliest-deadline variants are useful as urgency baselines, but they trail the optimized global policy in both success and mean kill ratio.
- **The result is still capacity constrained:** even the best strategy leaves pass-through risk, so future gains likely require softer handoff rules, more defenders, faster defenders, or a shorter dwell requirement.

## Figure Guide

- Figure 1: `01_assignment_flexibility_uplift.png` - Shows how optimized performance improves as allocation moves from rigid corridors to collaboration and global assignment.
- Figure 2: `02_capability_envelope.png` - Maps where the strongest strategy families remain viable as attacker load rises and defender resources increase.
- Figure 3: `03_defender_resource_scaling.png` - Shows that the strongest strategy families scale materially as additional defenders are added.
- Figure 4: `04_paired_scenario_conversion_matrix.png` - Compares optimized global against optimized on identical scenarios to isolate true algorithmic gains.
- Figure 5: `05_attacker_load_cliff.png` - Shows the sharp system success collapse once the swarm moves beyond the moderate-load regime.
- Figure 6: `06_residual_failure_space.png` - Shows that the remaining failure regime is concentrated in high-load saturation cases for optimized global control.
- Figure 7: `07_kill_ratio_distribution.png` - Shows consistency and tail behavior beyond mean performance.
- Figure 8: `08_terminal_time_distribution.png` - Shows whether strategies delay breach or finish quickly.
- Figure 9: `09_global_vs_corridor_success_uplift.png` - Compares hard corridors, collaborative corridors, and global assignment.
- Figure 10: `10_optimized_global_kill_ratio_delta.png` - Shows how often global optimization improves or hurts individual scenarios.

## Overall Metrics

| Strategy | Success rate | Mean kills | Mean kill ratio | Median completion time |
| --- | ---: | ---: | ---: | ---: |
| Optimized Global | 0.0% | 85.58 | 0.121 | 610.38s |
| Optimized Collab | 0.5% | 595.64 | 0.810 | 583.88s |
| Optimized Corridor | 0.0% | 583.98 | 0.793 | 596.62s |
| Nearest Global | 0.0% | 74.19 | 0.104 | 610.38s |
| Nearest Collab | 0.5% | 582.59 | 0.793 | 584.75s |
| Nearest Corridor | 0.0% | 571.00 | 0.777 | 598.38s |
| Deadline Global | 0.0% | 2.47 | 0.004 | 610.38s |
| Deadline Collab | 5.5% | 554.36 | 0.755 | 599.25s |
| Deadline Corridor | 3.5% | 553.60 | 0.754 | 599.25s |

## Best Operating Regimes

- Deadline Collab with 90 defenders vs 500-599 attackers: 60.0% success across 5 runs.
- Deadline Collab with 100 defenders vs 500-599 attackers: 40.0% success across 5 runs.
- Deadline Corridor with 90 defenders vs 500-599 attackers: 40.0% success across 5 runs.
- Deadline Collab with 100 defenders vs 600-700 attackers: 33.3% success across 6 runs.
- Deadline Corridor with 100 defenders vs 600-700 attackers: 33.3% success across 6 runs.
- Optimized Collab with 100 defenders vs 500-599 attackers: 20.0% success across 5 runs.
- Nearest Collab with 100 defenders vs 500-599 attackers: 20.0% success across 5 runs.
- Deadline Collab with 80 defenders vs 500-599 attackers: 20.0% success across 5 runs.
