# Publication Figure Index

L1. `01_success_rate_by_strategy.png` - **Mission success rate by strategy.** Shows which strategy most often kills all attackers before breach.
L2. `02_mean_kill_ratio_by_strategy.png` - **Average fraction of attackers killed.** Normalizes kills by scenario size so mixed attacker counts can be compared.
L3. `03_mean_kills_by_strategy.png` - **Average attackers killed per scenario.** Reports the absolute number of intercepted attackers before breach.
L4. `04_success_rate_by_defender_count.png` - **Success rate by defender count.** Shows how added defensive assets change mission outcomes.
L5. `05_success_rate_by_attacker_load.png` - **Success rate by attacker load.** Compares strategy robustness as attacker counts grow.
L6. `06_success_rate_heatmap.png` - **Success heatmap.** Identifies operating regimes where each strategy is viable.
C1. `01_assignment_flexibility_uplift.png` - **Assignment flexibility uplift.** Shows how optimized performance improves as allocation moves from rigid corridors to collaboration and global assignment.
C2. `02_capability_envelope.png` - **Capability envelope.** Maps where the strongest strategy families remain viable as attacker load rises and defender resources increase.
C3. `03_defender_resource_scaling.png` - **Defender resource scaling mechanics.** Shows that the strongest strategy families scale materially as additional defenders are added.
C4. `04_paired_scenario_conversion_matrix.png` - **Paired scenario conversion matrix.** Compares optimized global against optimized on identical scenarios to isolate true algorithmic gains.
C5. `05_attacker_load_cliff.png` - **Attacker load cliff.** Shows the sharp system success collapse once the swarm moves beyond the moderate-load regime.
C6. `06_residual_failure_space.png` - **Residual failure space.** Shows that the remaining failure regime is concentrated in high-load saturation cases for optimized global control.
7. `07_kill_ratio_distribution.png` - **Kill ratio distribution.** Shows consistency and tail behavior beyond mean performance.
8. `08_terminal_time_distribution.png` - **Terminal event timing.** Shows whether strategies delay breach or finish quickly.
9. `09_global_vs_corridor_success_uplift.png` - **Success by assignment mode.** Compares hard corridors, collaborative corridors, and global assignment.
10. `10_optimized_global_kill_ratio_delta.png` - **Optimized global per-scenario delta.** Shows how often global optimization improves or hurts individual scenarios.
