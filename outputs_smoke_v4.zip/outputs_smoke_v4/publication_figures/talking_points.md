# Publication Talking Points

Dataset: `outputs_smoke_v4/per_run_results.csv`.
Sample: 250 scenarios and 2250 strategy runs.

## Main Claims

- **Best overall strategy:** `optimized_global` achieved 0.0% mission success.
- **Best attrition strategy:** `optimized_collab` achieved a mean kill ratio of 0.765.
- **Removing corridors helped optimization:** `optimized_global` improved success from 0.0% to 0.0% (+0.0 percentage points).
- **Optimized global intercepted more attackers:** mean kills rose from 553.79 to 96.84 per scenario.
- **Collaborative corridors are the middle ground:** `optimized_collab` achieved 0.0% success and 567.86 mean kills while preserving corridor-first behavior.
- **Scenario-level improvement:** `optimized_global` killed more attackers than corridor `optimized` in 0.0% of paired scenarios, tied in 0.0%, and killed fewer in 100.0%.
- **Success conversion:** `optimized_global` turned 0 scenarios from corridor-optimized failures into successes.
- **Collaboration conversion:** `optimized_collab` turned 0 corridor-optimized failures into successes and improved kill count in 93.2% of paired scenarios.
- **Deadline-first policies are not enough:** earliest-deadline variants are useful as urgency baselines, but they trail the optimized global policy in both success and mean kill ratio.
- **The result is still capacity constrained:** even the best strategy leaves pass-through risk, so future gains likely require softer handoff rules, more defenders, faster defenders, or a shorter dwell requirement.

## Figure Guide

- Figure L1: `01_success_rate_by_strategy.png` - Shows which strategy most often kills all attackers before breach.
- Figure L2: `02_mean_kill_ratio_by_strategy.png` - Normalizes kills by scenario size so mixed attacker counts can be compared.
- Figure L3: `03_mean_kills_by_strategy.png` - Reports the absolute number of intercepted attackers before breach.
- Figure L4: `04_success_rate_by_defender_count.png` - Shows how added defensive assets change mission outcomes.
- Figure L5: `05_success_rate_by_attacker_load.png` - Compares strategy robustness as attacker counts grow.
- Figure L6: `06_success_rate_heatmap.png` - Identifies operating regimes where each strategy is viable.
- Figure C1: `01_assignment_flexibility_uplift.png` - Shows how optimized performance improves as allocation moves from rigid corridors to collaboration and global assignment.
- Figure C2: `02_capability_envelope.png` - Maps where the strongest strategy families remain viable as attacker load rises and defender resources increase.
- Figure C3: `03_defender_resource_scaling.png` - Shows that the strongest strategy families scale materially as additional defenders are added.
- Figure C4: `04_paired_scenario_conversion_matrix.png` - Compares optimized global against optimized on identical scenarios to isolate true algorithmic gains.
- Figure C5: `05_attacker_load_cliff.png` - Shows the sharp system success collapse once the swarm moves beyond the moderate-load regime.
- Figure C6: `06_residual_failure_space.png` - Shows that the remaining failure regime is concentrated in high-load saturation cases for optimized global control.
- Figure 7: `07_kill_ratio_distribution.png` - Shows consistency and tail behavior beyond mean performance.
- Figure 8: `08_terminal_time_distribution.png` - Shows whether strategies delay breach or finish quickly.
- Figure 9: `09_global_vs_corridor_success_uplift.png` - Compares hard corridors, collaborative corridors, and global assignment.
- Figure 10: `10_optimized_global_kill_ratio_delta.png` - Shows how often global optimization improves or hurts individual scenarios.

## Overall Metrics

| Strategy | Success rate | Mean kills | Mean kill ratio | Median completion time |
| --- | ---: | ---: | ---: | ---: |
| Optimized Global | 0.0% | 96.84 | 0.136 | 609.25s |
| Optimized Collab | 0.0% | 567.86 | 0.765 | 597.50s |
| Optimized Corridor | 0.0% | 553.79 | 0.746 | 600.25s |
| Nearest Global | 0.0% | 84.86 | 0.119 | 609.25s |
| Nearest Collab | 0.0% | 547.78 | 0.740 | 600.50s |
| Nearest Corridor | 0.0% | 534.79 | 0.722 | 601.25s |
| Deadline Global | 0.0% | 2.40 | 0.003 | 609.25s |
| Deadline Collab | 0.0% | 483.36 | 0.657 | 601.25s |
| Deadline Corridor | 0.0% | 482.94 | 0.656 | 601.25s |

## Best Operating Regimes

- Optimized Global with 100 defenders vs 950-1050 attackers: 0.0% success across 3 runs.
- Optimized Global with 100 defenders vs 850-949 attackers: 0.0% success across 6 runs.
- Optimized Global with 100 defenders vs 750-849 attackers: 0.0% success across 3 runs.
- Optimized Global with 100 defenders vs 600-700 attackers: 0.0% success across 6 runs.
- Optimized Global with 100 defenders vs 500-599 attackers: 0.0% success across 7 runs.
- Optimized Global with 90 defenders vs 950-1050 attackers: 0.0% success across 3 runs.
- Optimized Global with 90 defenders vs 850-949 attackers: 0.0% success across 6 runs.
- Optimized Global with 90 defenders vs 750-849 attackers: 0.0% success across 3 runs.
